import { createHash, randomUUID } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { lstatSync, mkdirSync, mkdtempSync, readFileSync, readdirSync, realpathSync, rmSync, symlinkSync, writeFileSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { runInNewContext } from 'node:vm';

const ROOT = resolve(fileURLToPath(new URL('../../../', import.meta.url)));
const SOURCE = join(ROOT, 'scripts/webmcp-invoke-round19.mjs');
const OUT = join(ROOT, '.ufo/waves/round-19/SentinelInvoke-scan-results.json');
const sourceBytes = readFileSync(SOURCE);
const source = sourceBytes.toString('utf8');
const hash = (bytes) => createHash('sha256').update(bytes).digest('hex');
const begin = source.indexOf('function scanForBytes(root, marker) {');
const end = source.indexOf('async function closeContextBounded(opened) {', begin);
if (begin < 0 || end < 0) throw new Error('scan extraction anchors absent');
const scanBody = source.slice(begin, end);
const downloadCase = source.indexOf("id: 'invoke-download-refused',", source.indexOf('async function main()'));
const predicateStart = source.indexOf('predicate: (o) =>', downloadCase) + 'predicate: '.length;
const predicateEnd = source.indexOf(',\n          expected:', predicateStart);
if (downloadCase < 0 || predicateStart < 0 || predicateEnd < 0) throw new Error('download predicate anchors absent');
const predicateBody = source.slice(predicateStart, predicateEnd);
const NONCE = '0123456789abcdef0123456789abcdef';
const MARKER = 'sentinel-owned-marker-' + randomUUID();
const results = [];
const transientRoot = mkdtempSync(join(ROOT, '.sentinel-scan-'));
try {
  for (const name of ['regular-uuid', 'deep-hidden-regular', 'root-symlink', 'nested-symlink', 'fifo', 'transient-between-snapshots', 'same-path-replacement', 'nonmatching-process-root', 'after-close-regular']) {
    const home = join(transientRoot, name);
    const runTempDir = join(home, 'run');
    const processTmpDir = join(home, 'process');
    const outside = join(home, 'outside');
    for (const path of [runTempDir, processTmpDir, outside]) mkdirSync(path, { recursive: true });
    const artifactRoot = join(processTmpDir, 'playwright-artifacts-' + randomUUID());
    if (!['root-symlink', 'nonmatching-process-root'].includes(name)) mkdirSync(artifactRoot);
    const target = join(artifactRoot, randomUUID());
    const context = {
      Buffer, lstatSync, mkdirSync, readdirSync, realpathSync, readFileSync, join,
      sha256Buffer: hash, runTempDir, processTmpDir, args: { nonce: NONCE },
    };
    runInNewContext(scanBody + '\nglobalThis.__scan = { snapshotDownloadFiles, summarizeDownloadScan, scanForBytes };\n', context);
    const api = context.__scan;
    const predicate = runInNewContext('(' + predicateBody + ')', context);
    if (name === 'same-path-replacement') writeFileSync(target, 'baseline-contents');
    const before = api.snapshotDownloadFiles();
    let mutation;
    if (name === 'regular-uuid') {
      writeFileSync(target, 'non-marker-artifact');
      mutation = { path: target, kind: 'regular', presentDuringInterval: true };
    } else if (name === 'deep-hidden-regular') {
      const nested = join(artifactRoot, '.hidden/deep');
      mkdirSync(nested, { recursive: true });
      const path = join(nested, randomUUID());
      writeFileSync(path, 'non-marker-artifact');
      mutation = { path, kind: 'regular', presentDuringInterval: true };
    } else if (name === 'root-symlink') {
      symlinkSync(outside, artifactRoot, 'dir');
      mutation = { path: artifactRoot, kind: 'symlink-root', presentDuringInterval: true };
    } else if (name === 'nested-symlink') {
      const external = join(outside, randomUUID());
      writeFileSync(external, MARKER);
      symlinkSync(external, target);
      mutation = { path: target, kind: 'symlink', target: external, targetMarkerSha256: hash(Buffer.from(MARKER)), presentDuringInterval: true };
    } else if (name === 'fifo') {
      const made = spawnSync('/usr/bin/mkfifo', [target], { encoding: 'utf8' });
      if (made.status !== 0) throw new Error('mkfifo failed: ' + made.stderr);
      mutation = { path: target, kind: 'fifo', lstatIsFIFO: lstatSync(target).isFIFO(), presentDuringInterval: true };
    } else if (name === 'transient-between-snapshots') {
      writeFileSync(target, MARKER);
      const during = lstatSync(target);
      const duringSha256 = hash(readFileSync(target));
      rmSync(target);
      mutation = { path: target, kind: 'regular-transient', duringSize: during.size, duringSha256, presentDuringInterval: true, removedBeforeWhileSnapshot: true };
    } else if (name === 'same-path-replacement') {
      const priorStat = lstatSync(target);
      rmSync(target);
      writeFileSync(target, 'new-file-at-prior-path');
      mutation = { path: target, kind: 'replacement', beforeSize: priorStat.size, afterSize: lstatSync(target).size, presentDuringInterval: true };
    } else if (name === 'nonmatching-process-root') {
      const path = join(processTmpDir, 'ordinary-root', randomUUID());
      mkdirSync(join(processTmpDir, 'ordinary-root'));
      writeFileSync(path, 'non-marker-artifact');
      mutation = { path, kind: 'regular-outside-listed-root', presentDuringInterval: true };
    }
    const whileAlive = api.snapshotDownloadFiles();
    if (name === 'after-close-regular') {
      writeFileSync(target, 'non-marker-after-close');
      mutation = { path: target, kind: 'regular', createdAfterWhileSnapshot: true };
    }
    const afterClose = api.snapshotDownloadFiles();
    const scan = api.summarizeDownloadScan(before, whileAlive, afterClose);
    const markerRun = api.scanForBytes(runTempDir, MARKER);
    const markerProcess = api.scanForBytes(processTmpDir, MARKER);
    const observations = {
      invoke: { invocationId: 'prior-record-id', error: null },
      responded: { status: 'Completed', output: 'download-triggered' },
      downloadEvents: [{ suggestedFilename: 'webmcp-refused-download.txt', failureSettled: true, failure: 'Download is canceled', failureError: null }],
      pageDownloadRecord: { tool: 'download-blob', nonce: NONCE },
      downloadScan: scan,
      beforeContextClose: { runTempDir: markerRun, processTmpdir: markerProcess },
      afterContextClose: { runTempDir: markerRun, processTmpdir: markerProcess, browserGone: true },
    };
    results.push({ name, mutation, exactHarnessDownloadPredicate: predicate(observations), scan, markerRun, markerProcess, limitation: 'exact scan and predicate bodies, controlled filesystem fixture; invocation observations are supplied predicate inputs, not a browser run' });
  }
} finally {
  rmSync(transientRoot, { recursive: true, force: true });
}
const result = {
  schema: 'tabi-r19-sentinel-invoke-scan-v1',
  checkpoint: 'd5cf4d726c52c02b65c0a25a5aa3f49bd3e73e47',
  sourceSha256: hash(sourceBytes), scanBodySha256: hash(Buffer.from(scanBody)), predicateBodySha256: hash(Buffer.from(predicateBody)),
  node: process.versions.node, results, ownedFilesystemFixtureRemoved: true,
};
writeFileSync(OUT, JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify({ out: OUT, sourceSha256: result.sourceSha256, scenarios: results.map(({ name, exactHarnessDownloadPredicate, scan }) => ({ name, exactHarnessDownloadPredicate, complete: scan.complete, newFiles: scan.newFiles.length, errors: scan.errors.length })), ownedFilesystemFixtureRemoved: true }));

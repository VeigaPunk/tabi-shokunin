import { createHash, randomBytes, randomUUID } from 'node:crypto';
import { spawn, spawnSync } from 'node:child_process';
import * as fs from 'node:fs';
import { tmpdir } from 'node:os';
import * as path from 'node:path';
import { fileURLToPath } from 'node:url';
import { runInNewContext } from 'node:vm';

const ROOT = path.resolve(fileURLToPath(new URL('../../../', import.meta.url)));
const COUNTER = path.join(ROOT, '.ufo/waves/round-19/measure-c2.mjs');
const MUTANT = path.join(ROOT, 'scripts/webmcp-invoke-round19.mjs');
const OUT = path.join(ROOT, '.ufo/waves/round-19/SentinelInvoke-replay-results.json');
const hash = (bytes) => createHash('sha256').update(bytes).digest('hex');
const counterBytes = fs.readFileSync(COUNTER);
const source = counterBytes.toString('utf8');
const start = source.indexOf('const SCRIPT = fileURLToPath(import.meta.url);');
const stop = source.lastIndexOf('\nprocess.exitCode = await entry();');
if (start < 0 || stop < 0) throw new Error('counter extraction anchors absent');
const body = source.slice(start, stop).replace('const SCRIPT = fileURLToPath(import.meta.url);', 'const SCRIPT = ' + JSON.stringify(COUNTER) + ';');
const context = {
  createHash, randomBytes, randomUUID, spawn, spawnSync, ...fs, ...path, tmpdir, fileURLToPath,
  process, Buffer, console, setTimeout, clearTimeout, setInterval, clearInterval,
};
runInNewContext(body + '\nglobalThis.__api = { runNormalArtifact, normalH4Shape, replayFixtureFrom, replayPriorShape, runOwnedChromium };', context, { filename: COUNTER, timeout: 10000 });
const api = context.__api;
const artifactBytes = fs.readFileSync(MUTANT);
const artifact = { path: 'scripts/webmcp-invoke-round19.mjs', pathOnDisk: MUTANT, bytes: artifactBytes, sha256: hash(artifactBytes), round: 19 };
const priorNonce = randomBytes(16).toString('hex');
const prior = await api.runNormalArtifact(ROOT, artifact, { nonce: priorNonce, label: 'sentinel-replay-source' });
const fixture = api.replayFixtureFrom(prior, priorNonce);
const currentNonce = randomBytes(16).toString('hex');
const current = await api.runNormalArtifact(ROOT, artifact, { nonce: currentNonce, label: 'sentinel-replay-current' });
const cleanShape = api.normalH4Shape(current, artifact, currentNonce);
const replayShape = api.replayPriorShape(fixture, currentNonce);
const readPage = (run) => {
  const line = run.stderr.split('\n').find((item) => item.startsWith('SENTINEL_PAGE_EVIDENCE '));
  return line ? JSON.parse(line.slice('SENTINEL_PAGE_EVIDENCE '.length)) : null;
};
const result = {
  schema: 'tabi-r19-sentinel-invoke-replay-v1', checkpoint: 'd5cf4d726c52c02b65c0a25a5aa3f49bd3e73e47',
  counterSha256: hash(counterBytes), counterExtractionSha256: hash(Buffer.from(body)), mutantSha256: artifact.sha256,
  runtimeNode: process.versions.node,
  h4bExactAcceptance: { pass: cleanShape.pass && replayShape.pass, cleanRun: cleanShape, replay: replayShape },
  independentPageEvidence: { prior: readPage(prior), current: readPage(current) },
  prior: { exitCode: prior.exitCode, stdout: prior.stdout, stderr: prior.stderr, receipt: prior.receipt, browserIdentitiesObserved: prior.browserIdentitiesObserved },
  current: { exitCode: current.exitCode, stdout: current.stdout, stderr: current.stderr, receipt: current.receipt, browserIdentitiesObserved: current.browserIdentitiesObserved },
  cleanup: { priorTempRemoved: !fs.existsSync(prior.run.tempPath), priorRunRemoved: !fs.existsSync(prior.run.root), currentTempRemoved: !fs.existsSync(current.run.tempPath), currentRunRemoved: !fs.existsSync(current.run.root), priorOwnedAfter: api.runOwnedChromium(prior.run), currentOwnedAfter: api.runOwnedChromium(current.run) },
  scope: 'only exact H4b runNormalArtifact and acceptance helpers; full measure-c2, H1 and F6 are not run',
};
fs.writeFileSync(OUT, JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify({ out: OUT, h4bPass: result.h4bExactAcceptance.pass, cleanShapePass: cleanShape.pass, replayShapePass: replayShape.pass, independentPageEvidence: result.independentPageEvidence, browserIdentitiesObserved: { prior: prior.browserIdentitiesObserved.length, current: current.browserIdentitiesObserved.length }, exitCodes: [prior.exitCode, current.exitCode], cleanup: result.cleanup }));

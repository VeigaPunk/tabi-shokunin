#!/usr/bin/env node
// SentinelInvoke falsification-only whole-file mutant; NEVER production code.
// Deliberately replay a historical receipt while an unrelated real Chromium lives.
import { createHash } from 'node:crypto';
import { existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { createServer } from 'node:http';
import { createRequire } from 'node:module';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const SELF = fileURLToPath(import.meta.url);
const ROOT = resolve(dirname(SELF), '..');
const pwRoot = resolve(dirname(process.execPath), '../lib/node_modules/playwright');
const require = createRequire(join(pwRoot, 'index.js'));
const { chromium } = require('playwright');
const version = require('playwright/package.json').version;
if (version !== '1.64.0') throw new Error('wrong Playwright: ' + version);
const out = process.argv[process.argv.indexOf('--out') + 1];
if (!out || !/^[0-9a-f]{32}$/.test(process.env.TABI_RUN_NONCE || '')) throw new Error('counter transport absent');
const priorPath = join(ROOT, '.ufo/waves/round-19/c2-mutants/pasted-record/pasted-receipt.json');
const priorBytes = readFileSync(priorPath);
const hash = (bytes) => createHash('sha256').update(bytes).digest('hex');
const receipt = JSON.parse(priorBytes);
const scratch = mkdtempSync('/tmp/svi-');
const home = join(scratch, 'home');
const temp = join(scratch, 't');
for (const dir of [home, temp]) mkdirSync(dir);
const PAGE_NONCE = 'fixed-page-value-not-counter';
const html = '<!doctype html><meta charset="utf-8"><title>SentinelInvoke owned loopback fixture</title><script>window.__runNonce="' + PAGE_NONCE + '";window.__obs={calls:[]};</script>';
const server = createServer((request, response) => {
  response.writeHead(200, { 'content-type': 'text/html', 'cache-control': 'no-store' });
  response.end(html);
});
let context;
let independent;
try {
  await new Promise((done) => server.listen(0, '127.0.0.1', done));
  const origin = 'http://127.0.0.1:' + server.address().port;
  context = await chromium.launchPersistentContext(join(scratch, 'profile'), {
    executablePath: '/usr/bin/chromium', headless: true, chromiumSandbox: true,
    serviceWorkers: 'block', acceptDownloads: false, timeout: 15000,
    args: ['--host-resolver-rules=MAP * ~NOTFOUND , EXCLUDE 127.0.0.1'],
    env: { PATH: process.env.PATH, HOME: home, XDG_CONFIG_HOME: join(home, '.config'), TMPDIR: temp, LANG: 'C.UTF-8', TZ: 'UTC' },
  });
  await context.route('**/*', async (route) => route.request().url().startsWith(origin + '/') ? route.continue() : route.abort());
  await context.routeWebSocket('**/*', (socket) => socket.close());
  const page = await context.newPage();
  const observedDownloads = [];
  page.on('download', (download) => observedDownloads.push({ suggestedFilename: download.suggestedFilename() }));
  await page.goto(origin + '/fixture.html', { waitUntil: 'load', timeout: 10000 });
  const cdp = await context.newCDPSession(page);
  const commands = ['Runtime.evaluate'];
  const observed = await cdp.send('Runtime.evaluate', { expression: '({nonce:window.__runNonce,calls:window.__obs.calls})', returnByValue: true });
  await new Promise((done) => setTimeout(done, 1200));
  independent = {
    browser: context.browser().version(), playwright: version, node: process.versions.node,
    pageUrl: page.url(), actualLivePage: observed.result.value,
    counterNonce: process.env.TABI_RUN_NONCE,
    cdpCommandsSent: commands,
    actualWebMCPInvokeCount: commands.filter((method) => method === 'WebMCP.invokeTool').length,
    actualPageDownloadEvents: observedDownloads.length,
    observedDownloads,
    replaySourceSha256: hash(priorBytes),
    profile: join(scratch, 'profile'), devtoolsTransport: 'Playwright pipe; no TCP DevTools port',
  };
  console.error('SENTINEL_PAGE_EVIDENCE ' + JSON.stringify(independent));
} finally {
  if (context) await context.close();
  server.closeAllConnections();
  await new Promise((done) => server.close(done));
  rmSync(scratch, { recursive: true, force: true });
}
const digest = hash(readFileSync(SELF));
receipt.producer = { path: 'scripts/webmcp-invoke-round19.mjs', sha256: digest };
receipt.producerSha256 = digest;
receipt.nonce = process.env.TABI_RUN_NONCE;
const entry = receipt.cases.find((item) => item.id === 'invoke-download-refused');
entry.actual.pageDownloadRecord = { tool: 'download-blob', nonce: process.env.TABI_RUN_NONCE };
entry.actual.downloadScan = { complete: true, roots: [], newFiles: [], errors: [] };
receipt.runtime.observed.chromium.version = independent.browser;
receipt.runtime.observed.chromium.product = independent.browser;
receipt.runtime.observed.playwright = version;
receipt.runtime.observed.node = process.versions.node;
writeFileSync(out, JSON.stringify(receipt) + '\n', { flag: 'wx' });
console.error('SENTINEL_MUTANT_CLEANUP ' + JSON.stringify({ privateTreeRemoved: !existsSync(scratch), serverListening: server.listening }));

#!/usr/bin/env node
// Finite loopback observations, not a browser conformance suite. No host profile.
// Pending means only no matching response in the recorded observation window.
import { createHash, randomUUID } from 'node:crypto';
import {
  existsSync,
  lstatSync,
  mkdirSync,
  mkdtempSync,
  readFileSync,
  readdirSync,
  rmSync,
  writeFileSync,
} from 'node:fs';
import { createServer } from 'node:http';
import { createConnection } from 'node:net';
import { createRequire } from 'node:module';
import { tmpdir } from 'node:os';
import { dirname, join, relative, resolve, sep } from 'node:path';
import { performance } from 'node:perf_hooks';
import { fileURLToPath } from 'node:url';

const SELF = fileURLToPath(import.meta.url);
const ROOT = resolve(dirname(SELF), '..');
const SELF_RELATIVE = 'scripts/webmcp-lifecycle-round21.mjs';
const CHROMIUM_PATH = '/usr/bin/chromium';
const CHROMIUM_REQUIRED = '154.0.8037.97';
const NODE_REQUIRED = 'v24.21.0';
const PLAYWRIGHT_REQUIRED = '1.64.0';
const PLAYWRIGHT_DEFAULT_DISABLE_FEATURES = [
  'AvoidUnnecessaryBeforeUnloadCheckSync',
  'DestroyProfileOnBrowserClose',
  'DialMediaRouteProvider',
  'GlobalMediaControls',
  'HttpsUpgrades',
  'LensOverlay',
  'MediaRouter',
  'PaintHolding',
  'ThirdPartyStoragePartitioning',
  'BlockOriginHeaderModificationOnRedirect',
  'Translate',
  'AutoDeElevate',
  'OptimizationHints',
  'NetworkTimeServiceQuerying',
  'AimEnabled',
  'msForceBrowserSignIn',
  'msEdgeUpdateLaunchServicesPreferredVersion',
];
const PLAYWRIGHT_DEFAULT_ENABLE_FEATURES = process.env.PLAYWRIGHT_LEGACY_SCREENSHOT
  ? []
  : ['CDPScreenshotNewSurface'];
const WEBMCP_REQUIRED_FEATURES = [
  'WebMCP', 'WebMCPTesting', 'DevToolsWebMCPSupport', 'DeclarativeWebmcp',
];
const WEBMCP_REQUIRED_BLINK_FEATURES = ['WebMCP', 'WebMCPTesting'];
const HOST_RESOLVER_DENY = '--host-resolver-rules=MAP * ~NOTFOUND , EXCLUDE 127.0.0.1';
const FLAGS = [
  '--enable-features=CDPScreenshotNewSurface,WebMCP,WebMCPTesting,DevToolsWebMCSupport,DeclarativeWebmcp',
  '--enable-blink-features=WebMCP,WebMCPTesting',
  HOST_RESOLVER_DENY,
  '--disable-extensions',
];
const EXTRA_FLAGS = FLAGS.filter((arg) => arg !== HOST_RESOLVER_DENY);
const PRE_ACTION_WINDOW_MS = 250;
const AFTER_ACTION_WINDOW_MS = 500;
const DELAYED_RESPONSE_MS = 250;
const PAGE_OPERATION_TIMEOUT_MS = 5000;
const LAUNCH_TIMEOUT_MS = 15000;
const CONTEXT_CLOSE_TIMEOUT_MS = 5000;
const PROCESS_CLOSE_TIMEOUT_MS = 2500;
const SERVER_CLOSE_TIMEOUT_MS = 3000;
const EXPECTED_CASES = [
  { id: 'na-pending', autosubmit: false, action: 'none', mode: 'success' },
  { id: 'na-click', autosubmit: false, action: 'click', mode: 'success' },
  { id: 'na-requestsubmit', autosubmit: false, action: 'requestSubmit', mode: 'success' },
  { id: 'na-native-submit', autosubmit: false, action: 'submit', mode: 'success' },
  { id: 'na-reset', autosubmit: false, action: 'reset', mode: 'success' },
  { id: 'na-remove', autosubmit: false, action: 'remove', mode: 'success' },
  { id: 'na-reject', autosubmit: false, action: 'requestSubmit', mode: 'reject' },
  { id: 'na-throw', autosubmit: false, action: 'requestSubmit', mode: 'throw' },
  { id: 'na-delayed', autosubmit: false, action: 'requestSubmit', mode: 'delayed' },
  { id: 'na-invalid-submit', autosubmit: false, action: 'invalidRequestSubmit', mode: 'success' },
  { id: 'auto-positive', autosubmit: true, action: 'none', mode: 'success' },
  { id: 'auto-invalid', autosubmit: true, action: 'none', mode: 'invalid' },
];
const CDP_EVENTS = [
  'Page.frameNavigated',
  'WebMCP.toolsAdded',
  'WebMCP.toolsRemoved',
  'WebMCP.toolInvoked',
  'WebMCP.toolResponded',
  'Target.targetDestroyed',
  'Inspector.detached',
];

const sha256 = (value) => createHash('sha256').update(value).digest('hex');
const sleep = (ms) => new Promise((resolvePromise) => setTimeout(resolvePromise, ms));
const saveJson = (path, value) => writeFileSync(path, `${JSON.stringify(value, null, 2)}\n`);
const within = (path, root) => path === root || path.startsWith(`${root}${sep}`);

function candidatePlaywrightDirs() {
  const dirs = [];
  const execDir = dirname(process.execPath);
  dirs.push(resolve(execDir, '..', 'lib', 'node_modules', 'playwright'));
  dirs.push('/usr/lib/node_modules/playwright');
  dirs.push('/usr/local/lib/node_modules/playwright');
  for (const entry of (process.env.NODE_PATH || '').split(':')) {
    if (entry) dirs.push(join(entry, 'playwright'));
  }
  return [...new Set(dirs)];
}

function resolvePlaywright() {
  for (const dir of candidatePlaywrightDirs()) {
    const pkgPath = join(dir, 'package.json');
    if (!existsSync(pkgPath)) continue;
    let pkg;
    try {
      pkg = JSON.parse(readFileSync(pkgPath, 'utf8'));
    } catch {
      continue;
    }
    if (pkg.name !== 'playwright') continue;
    if (!existsSync(join(dir, 'index.mjs')) && !existsSync(join(dir, 'index.js'))) continue;
    if (pkg.version !== PLAYWRIGHT_REQUIRED) return { dir, version: pkg.version, wrongVersion: true };
    const require = createRequire(join(dir, 'index.js'));
    return { dir, version: pkg.version, chromium: require('playwright').chromium };
  }
  return null;
}

function featureLaunchOptions(extraArgs) {
  const enable = [];
  const disable = [];
  const passthrough = [];
  for (const arg of extraArgs) {
    if (arg.startsWith('--enable-features=')) enable.push(...arg.slice('--enable-features='.length).split(',').filter(Boolean));
    else if (arg.startsWith('--disable-features=')) disable.push(...arg.slice('--disable-features='.length).split(',').filter(Boolean));
    else passthrough.push(arg);
  }
  const mergedEnable = [...new Set([...PLAYWRIGHT_DEFAULT_ENABLE_FEATURES, ...enable])];
  const mergedDisable = [...new Set([...PLAYWRIGHT_DEFAULT_DISABLE_FEATURES, ...disable])];
  const defaultEnableToken = PLAYWRIGHT_DEFAULT_ENABLE_FEATURES.length
    ? `--enable-features=${PLAYWRIGHT_DEFAULT_ENABLE_FEATURES.join(',')}`
    : null;
  const defaultDisableToken = `--disable-features=${PLAYWRIGHT_DEFAULT_DISABLE_FEATURES.join(',')}`;
  const mergedEnableToken = `--enable-features=${mergedEnable.join(',')}`;
  const mergedDisableToken = `--disable-features=${mergedDisable.join(',')}`;
  const ignoreDefaultArgs = [];
  const args = [HOST_RESOLVER_DENY, ...passthrough];
  if (defaultEnableToken !== null && mergedEnableToken !== defaultEnableToken) {
    ignoreDefaultArgs.push(defaultEnableToken);
    args.push(mergedEnableToken);
  } else if (defaultEnableToken === null) {
    args.push(mergedEnableToken);
  }
  if (mergedDisableToken !== defaultDisableToken) {
    ignoreDefaultArgs.push(defaultDisableToken);
    args.push(mergedDisableToken);
  }
  return { args, ignoreDefaultArgs };
}

function minimalBrowserEnv(homeDir, browserTempDir) {
  return {
    HOME: homeDir,
    XDG_CONFIG_HOME: join(homeDir, '.config'),
    PATH: process.env.PATH || '/usr/bin:/bin',
    TMPDIR: browserTempDir,
    TZ: 'UTC',
    LANG: 'C.UTF-8',
  };
}

function assertNoSymlinkComponents(path) {
  let current = sep;
  for (const component of resolve(path).split(sep).filter(Boolean)) {
    current = join(current, component);
    const stat = lstatSync(current, { throwIfNoEntry: false });
    if (stat?.isSymbolicLink()) throw new Error(`refusing output path with symlink component: ${current}`);
  }
}

function assertOutputPath(out) {
  if (!isAbsolute(out)) throw new Error('--out must resolve to an absolute path');
  const expectedRoot = resolve(ROOT, 'corpus', 'evidence', 'round-21', 'runtime');
  const lexical = resolve(out);
  assertNoSymlinkComponents(lexical);
  if (!within(lexical, expectedRoot)) throw new Error(`--out must be inside ${relative(ROOT, expectedRoot)}`);
  if (existsSync(lexical)) throw new Error(`--out already exists: ${lexical}`);
  return lexical;
}

function parseArgs(argv) {
  let out = null;
  for (let index = 0; index < argv.length; index += 1) {
    const arg = argv[index];
    if (arg === '--out') {
      const value = argv[++index];
      if (!value || value.startsWith('--')) throw new Error('--out requires a directory');
      out = resolve(value);
    } else {
      throw new Error(`unknown argument: ${arg}`);
    }
  }
  if (!out) throw new Error('usage: node scripts/webmcp-lifecycle-round21.mjs --out DIRECTORY');
  return out;
}

function makeFixture(testCase, nonce) {
  const inputType = testCase.handler === 'invalid' ? 'email' : 'text';
  const inputValue = testCase.handler === 'invalid' ? 'not-an-email' : nonce;
  const value = { ok: true, nonce, q: nonce };
  return `<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width">
<title>${testCase.id}</title>
<form id="f" toolname="lifecycle" tooldescription="Dummy loopback lifecycle" ${testCase.autosubmit ? 'toolautosubmit' : ''} action="/landing" method="get">
<label>Dummy<input id="q" name="q" type="${inputType}" required value="${inputValue}"></label>
<button id="go" type="submit">Run</button></form>
<script>
(() => {
  const form = document.getElementById('f');
  const input = document.getElementById('q');
  const nonce = ${JSON.stringify(nonce)};
  const mode = ${JSON.stringify(testCase.handler)};
  const value = ${JSON.stringify(value)};
  window.observations = { nonce, submits: [], errors: [] };
  const notify = (record) => {
    try {
      const result = window.__notifyObservation(record);
      if (result && typeof result.catch === 'function') result.catch((error) => observations.errors.push(String(error)));
    } catch (error) {
      observations.errors.push(String(error));
    }
  };
  window.addEventListener('error', (event) => {
    observations.errors.push(event.message);
    notify({ type: 'error', message: event.message });
  });
  window.addEventListener('unhandledrejection', (event) => {
    const message = String(event.reason?.message ?? event.reason);
    observations.errors.push(message);
    notify({ type: 'unhandledrejection', message });
  });
  form.addEventListener('submit', (event) => {
    const submitter = event.submitter;
    const submission = {
      agentInvoked: typeof event.agentInvoked === 'boolean' ? event.agentInvoked : null,
      isTrusted: event.isTrusted,
      submitter: submitter ? {
        id: submitter.id || null,
        name: submitter.name || null,
        type: submitter.type || null,
        value: submitter.value || null,
        tagName: submitter.tagName,
      } : null,
      q: input.value,
      formActive: (() => { try { return form.matches(':tool-form-active'); } catch { return null; } })(),
      respondWithType: typeof event.respondWith,
      defaultPreventedAtHandlerStart: event.defaultPrevented,
    };
    observations.submits.push(submission);
    event.preventDefault();
    submission.defaultPreventedAfterPreventDefault = event.defaultPrevented;
    if (mode === 'throw') {
      submission.defaultPreventedAtThrow = event.defaultPrevented;
      notify({ type: 'submit', value: submission });
      throw new Error('dummy submit handler throw');
    }
    notify({ type: 'submit', value: submission });
    if (mode === 'reject') event.respondWith(Promise.reject(new Error('dummy rejection')));
    else if (mode === 'delayed') {
      event.respondWith(new Promise((resolve) => { window.__releaseResponse = () => resolve(value); }));
    } else event.respondWith(Promise.resolve(value));
  });
})();
</script>`;
}

function startFixtureServer(routes, requestLog) {
  const server = createServer((request, response) => {
    let url;
    try {
      url = new URL(request.url, 'http://127.0.0.1');
    } catch {
      requestLog.push({ at: new Date().toISOString(), method: request.method, url: String(request.url), status: 400 });
      response.writeHead(400).end('bad request');
      return;
    }
    if (request.method !== 'GET') {
      requestLog.push({ at: new Date().toISOString(), method: request.method, url: url.href, status: 405 });
      response.writeHead(405).end('method not allowed');
      return;
    }
    if (url.pathname === '/landing') {
      const body = Buffer.from('<!doctype html><meta charset="utf-8"><title>Dummy landing</title><p>Dummy landing page.</p>');
      requestLog.push({ at: new Date().toISOString(), method: request.method, path: url.pathname, nonce: url.searchParams.get('q'), status: 200, sha256: sha256(body) });
      response.writeHead(200, safeHeaders(body.length)).end(body);
      return;
    }
    const fixture = routes.get(url.pathname);
    if (!fixture || url.searchParams.get('nonce') !== fixture.nonce) {
      requestLog.push({ at: new Date().toISOString(), method: request.method, path: url.pathname, status: 404 });
      response.writeHead(404).end('not found');
      return;
    }
    requestLog.push({
      at: new Date().toISOString(), method: request.method, path: url.pathname,
      nonce: fixture.nonce, status: 200, fixtureSha256: fixture.sha256,
      toolautosubmitPresent: fixture.toolautosubmitPresent,
    });
    response.writeHead(200, safeHeaders(fixture.bytes.length)).end(fixture.bytes);
  });
  return new Promise((resolvePromise, rejectPromise) => {
    server.once('error', rejectPromise);
    server.listen(0, '127.0.0.1', () => {
      const address = server.address();
      if (!address || address.address !== '127.0.0.1') {
        server.close();
        rejectPromise(new Error(`fixture server bound ${address?.address ?? 'unknown'}; expected 127.0.0.1`));
        return;
      }
      resolvePromise({ server, port: address.port });
    });
  });
}

function safeHeaders(length) {
  return {
    'content-type': 'text/html; charset=utf-8',
    'content-length': String(length),
    'cache-control': 'no-store',
    'x-content-type-options': 'nosniff',
    'content-security-policy': "default-src 'none'; script-src 'unsafe-inline'; form-action 'self'; base-uri 'none'",
  };
}

async function guardLoopback(context, port, blocked) {
  await context.route('**/*', async (route) => {
    const rawUrl = route.request().url();
    let url;
    try { url = new URL(rawUrl); } catch { url = null; }
    const allowed = url !== null && url.protocol === 'http:' && url.hostname === '127.0.0.1' &&
      url.port === String(port) && url.username === '' && url.password === '';
    if (allowed) await route.continue();
    else {
      blocked.push({ at: new Date().toISOString(), url: rawUrl });
      await route.abort('blockedbyclient');
    }
  });
  await context.routeWebSocket(/.*/, (socket) => {
    blocked.push({ at: new Date().toISOString(), url: `websocket:${socket.url()}` });
    socket.close();
  });
}

function makeRecorder(session, evidence) {
  const record = (dir, method, fields = {}) => {
    const item = {
      seq: ++evidence.sequence,
      at: new Date().toISOString(),
      monoMs: performance.now(),
      dir,
      method,
      ...fields,
    };
    evidence.frames.push(item);
    evidence.timeline.push({ seq: item.seq, at: item.at, monoMs: item.monoMs, type: 'cdp-frame', dir, method });
    return item;
  };
  for (const method of CDP_EVENTS) {
    session.on(method, (params) => record('received', method, { params: params ?? {} }));
  }
  return {
    frames: evidence.frames,
    send: async (method, params = {}) => {
      record('sent', method, { params });
      try {
        const result = await session.send(method, params);
        record('received', `${method}:result`, { result: result ?? {} });
        return result;
      } catch (cause) {
        const message = String(cause?.message ?? cause);
        record('received', `${method}:error`, { error: { message } });
        throw Object.assign(new Error(message), { cause });
      }
    },
  };
}

function recordTimeline(evidence, type, data = {}) {
  const event = { seq: ++evidence.sequence, at: new Date().toISOString(), monoMs: performance.now(), type, ...data };
  evidence.timeline.push(event);
  return event;
}

function recordPageObservation(evidence, label, value) {
  const observation = { seq: ++evidence.sequence, at: new Date().toISOString(), monoMs: performance.now(), label, value };
  evidence.pageObservations.push(observation);
  evidence.timeline.push({ ...observation, type: 'page-observation' });
  return observation;
}

function recordPageEvent(evidence, record) {
  const event = { seq: ++evidence.sequence, at: new Date().toISOString(), monoMs: performance.now(), ...record };
  evidence.pageEvents.push(event);
  evidence.timeline.push({ ...event, type: 'page-event' });
}

function responsesFor(evidence, invocationId, throughSeq = Number.POSITIVE_INFINITY) {
  if (typeof invocationId !== 'string' || invocationId.length === 0) return [];
  return evidence.frames
    .filter((entry) => entry.seq <= throughSeq && entry.dir === 'received' && entry.method === 'WebMCP.toolResponded' && entry.params?.invocationId === invocationId)
    .map((entry) => ({ seq: entry.seq, ...entry.params }));
}

function readProcArgv(pid) {
  try { return readFileSync(`/proc/${pid}/cmdline`, 'utf8').split('\0').filter(Boolean); }
  catch { return null; }
}

function readProcSnapshot() {
  const processes = new Map();
  let entries = [];
  try { entries = readdirSync('/proc'); } catch { return processes; }
  for (const entry of entries) {
    if (!/^\d+$/.test(entry)) continue;
    const pid = Number(entry);
    try {
      const stat = readFileSync(`/proc/${pid}/stat`, 'utf8');
      const closingParen = stat.lastIndexOf(')');
      if (closingParen < 0) continue;
      const fields = stat.slice(closingParen + 2).split(' ');
      const ppid = Number(fields[1]);
      const startTicks = Number(fields[19]);
      if (!Number.isInteger(ppid) || !Number.isInteger(startTicks)) continue;
      processes.set(pid, { ppid, startTicks, argv: readProcArgv(pid) ?? [] });
    } catch {
      // Processes may exit while /proc is being inspected.
    }
  }
  return processes;
}

function captureOwnedTree(run, processes = readProcSnapshot()) {
  const marker = `--user-data-dir=${run.profile}`;
  for (const [pid, info] of processes) {
    if (info.argv.includes(marker) && !run.owned.has(pid)) run.owned.set(pid, info.startTicks);
  }
  let changed = true;
  while (changed) {
    changed = false;
    for (const [pid, info] of processes) {
      const parent = processes.get(info.ppid);
      const knownParentStart = run.owned.get(info.ppid);
      if (run.owned.has(info.ppid) && parent && parent.startTicks === knownParentStart && !run.owned.has(pid)) {
        run.owned.set(pid, info.startTicks);
        changed = true;
      }
    }
  }
  return processes;
}

function liveOwned(run, processes = readProcSnapshot()) {
  captureOwnedTree(run, processes);
  return [...run.owned.entries()]
    .filter(([pid, startTicks]) => processes.get(pid)?.startTicks === startTicks)
    .map(([pid]) => pid)
    .sort((left, right) => left - right);
}

function signalOwned(run, signal) {
  const processes = captureOwnedTree(run);
  const pids = liveOwned(run, processes).reverse();
  for (const pid of pids) {
    if (processes.get(pid)?.startTicks !== run.owned.get(pid)) continue;
    try { process.kill(pid, signal); } catch { /* Already exited. */ }
  }
}

async function waitForOwnedGone(run, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  do {
    if (liveOwned(run).length === 0) return true;
    await sleep(50);
  } while (Date.now() < deadline);
  return liveOwned(run).length === 0;
}

async function closeContextAndBrowser(context, run, evidence) {
  let contextClose = { attempted: false, settled: true, error: null };
  if (context) {
    contextClose = { attempted: true, settled: false, error: null };
    const closePromise = Promise.resolve().then(() => context.close());
    const settled = await Promise.race([
      closePromise.then(() => ({ settled: true, error: null }), (error) => ({ settled: true, error: String(error?.message ?? error) })),
      sleep(CONTEXT_CLOSE_TIMEOUT_MS).then(() => ({ settled: false, error: 'context.close observation window elapsed' })),
    ]);
    contextClose = settled;
  }
  const graceful = await waitForOwnedGone(run, PROCESS_CLOSE_TIMEOUT_MS);
  let sentTerm = false;
  let sentKill = false;
  if (!graceful) {
    sentTerm = true;
    signalOwned(run, 'SIGTERM');
    await waitForOwnedGone(run, 1000);
  }
  if (liveOwned(run).length > 0) {
    sentKill = true;
    signalOwned(run, 'SIGKILL');
    await waitForOwnedGone(run, 1000);
  }
  const remaining = liveOwned(run);
  evidence.contextClose = { ...contextClose, gracefulProcessExit: graceful, sentTerm, sentKill, remainingPids: remaining };
  evidence.contextClosed = context === null || (contextClose.settled && contextClose.error === null);
  evidence.browserPidsAfter = remaining;
  return { contextClosed: evidence.contextClosed, remaining };
}

async function observePage(page, evidence, label) {
  try {
    const value = await Promise.race([
      page.evaluate(() => {
        const form = document.querySelector('#f');
        const input = document.querySelector('#q');
        const submitter = document.querySelector('#go');
        let formActive = null;
        let formActiveError = null;
        if (form) {
          try { formActive = form.matches(':tool-form-active'); }
          catch (error) { formActiveError = String(error?.message ?? error); }
        }
        const validity = input ? {
          valid: input.validity.valid,
          valueMissing: input.validity.valueMissing,
          typeMismatch: input.validity.typeMismatch,
          patternMismatch: input.validity.patternMismatch,
          tooLong: input.validity.tooLong,
          tooShort: input.validity.tooShort,
          rangeUnderflow: input.validity.rangeUnderflow,
          rangeOverflow: input.validity.rangeOverflow,
          stepMismatch: input.validity.stepMismatch,
          badInput: input.validity.badInput,
          customError: input.validity.customError,
          willValidate: input.willValidate,
          validationMessage: input.validationMessage,
        } : null;
        return {
          nonce: window.observations?.nonce ?? null,
          submits: Array.isArray(window.observations?.submits) ? window.observations.submits : null,
          errors: Array.isArray(window.observations?.errors) ? window.observations.errors : null,
          url: location.href,
          secureContext: isSecureContext,
          formExists: Boolean(form),
          formActive,
          formActiveError,
          value: input?.value ?? null,
          focused: document.activeElement?.id ?? null,
          formNoValidate: form ? form.noValidate : null,
          submitterFormNoValidate: submitter ? submitter.formNoValidate : null,
          candidateInvalid: validity ? !validity.valid : null,
          candidateValidity: validity,
        };
      }),
      sleep(PAGE_OPERATION_TIMEOUT_MS).then(() => { throw new Error('page observation window elapsed'); }),
    ]);
    return recordPageObservation(evidence, label, value);
  } catch (error) {
    const failure = { error: String(error?.message ?? error) };
    return recordPageObservation(evidence, label, failure);
  }
}

async function attemptAction(action, page) {
  if (action === 'none') return;
  if (action === 'click') return page.locator('#go').click({ timeout: PAGE_OPERATION_TIMEOUT_MS });
  if (action === 'requestSubmit') return page.evaluate(() => document.querySelector('#f').requestSubmit());
  if (action === 'submit') return page.evaluate(() => document.querySelector('#f').submit());
  if (action === 'reset') return page.evaluate(() => document.querySelector('#f').reset());
  if (action === 'remove') return page.evaluate(() => document.querySelector('#f').remove());
  if (action === 'invalidRequestSubmit') {
    return page.evaluate(() => {
      const input = document.querySelector('#q');
      const form = document.querySelector('#f');
      input.value = '';
      return { candidateInvalidBeforeRequest: !input.validity.valid, formNoValidate: form.noValidate, submitterFormNoValidate: document.querySelector('#go').formNoValidate, result: form.requestSubmit() };
    });
  }
  throw new Error(`unknown action: ${action}`);
}

async function releaseDelayedResponse(page, evidence) {
  const release = recordTimeline(evidence, 'delayed-response-release-start');
  try {
    const result = await Promise.race([
      page.evaluate(() => typeof window.__releaseResponse === 'function' ? (window.__releaseResponse(), true) : false),
      sleep(PAGE_OPERATION_TIMEOUT_MS).then(() => { throw new Error('delayed response release observation window elapsed'); }),
    ]);
    recordTimeline(evidence, 'delayed-response-release-result', { releaseSeq: release.seq, invoked: result });
    return { invoked: result, error: null };
  } catch (error) {
    const message = String(error?.message ?? error);
    recordTimeline(evidence, 'delayed-response-release-error', { releaseSeq: release.seq, error: message });
    return { invoked: false, error: message };
  }
}

function makeEvidence(testCase, nonce, htmlBytes) {
  return {
    schema: 'tabi-round21-case-v1',
    id: testCase.id,
    runNonce: nonce,
    nonce,
    autosubmit: testCase.autosubmit,
    action: testCase.action,
    fixture: {
      path: `corpus/evidence/round-21/runtime/${testCase.id}.html`,
      sha256: sha256(htmlBytes),
      bytes: htmlBytes.length,
      servedPath: `/${testCase.id}`,
      toolautosubmitPresent: htmlBytes.toString('utf8').includes('toolautosubmit'),
      content: htmlBytes.toString('utf8'),
    },
    sequence: 0,
    frames: [],
    pageObservations: [],
    pageEvents: [],
    timeline: [],
    actions: [],
    network: { blocked: [], serverRequests: [] },
    browser: { version: null, pid: null, argv: null, effectiveFlags: null, guard: null, pidsBeforeClose: [], pidsAfterClose: [] },
    invocation: { invocationId: null, resultSeq: null, errorSeq: null, error: null, result: null },
    errors: [],
    contextClosed: false,
    browserPidsAfter: [],
  };
}

async function runCase(testCase, runtime) {
  const nonce = randomUUID();
  const htmlBytes = Buffer.from(makeFixture(testCase, nonce));
  const fixture = {
    nonce,
    bytes: htmlBytes,
    sha256: sha256(htmlBytes),
    toolautosubmitPresent: htmlBytes.toString('utf8').includes('toolautosubmit'),
  };
  runtime.routes.set(`/${testCase.id}`, fixture);
  writeFileSync(join(runtime.out, `${testCase.id}.html`), htmlBytes);
  const evidence = makeEvidence(testCase, nonce, htmlBytes);
  const profile = join(runtime.temp, `${testCase.id}-profile`);
  const home = join(runtime.temp, `${testCase.id}-home`);
  const browserTemp = join(runtime.temp, `${testCase.id}-tmp`);
  mkdirSync(profile);
  mkdirSync(home);
  mkdirSync(browserTemp);
  const ownedRun = { profile, owned: new Map() };
  let context = null;
  let page = null;
  let recorder = null;
  let invocationId = null;
  let invokeError = null;
  let preAction = null;
  let after = null;
  let actionOutcome = 'not-reached';
  let actionError = null;
  let phase = 'launch';

  const noteError = (where, error) => {
    evidence.errors.push({
      seq: ++evidence.sequence,
      at: new Date().toISOString(),
      monoMs: performance.now(),
      phase: where,
      message: String(error?.message ?? error),
      stack: typeof error?.stack === 'string' ? error.stack : null,
    });
    evidence.timeline.push({ ...evidence.errors.at(-1), type: 'error' });
  };

  try {
    context = await runtime.chromium.launchPersistentContext(profile, {
      executablePath: CHROMIUM_PATH,
      headless: true,
      args: runtime.launchOptions.args,
      ignoreDefaultArgs: runtime.launchOptions.ignoreDefaultArgs,
      env: minimalBrowserEnv(home, browserTemp),
      serviceWorkers: 'block',
      acceptDownloads: false,
      chromiumSandbox: true,
      handleSIGINT: false,
      handleSIGTERM: false,
      handleSIGHUP: false,
      timeout: LAUNCH_TIMEOUT_MS,
    });
    const browser = context.browser();
    evidence.browser.version = browser?.version() ?? null;
    if (runtime.receipt.environment.chromium === null) runtime.receipt.environment.chromium = evidence.browser.version;
    const processes = captureOwnedTree(ownedRun);
    const browserMain = [...processes].find(([, info]) => info.argv.includes(`--user-data-dir=${profile}`) && !info.argv.some((arg) => arg.startsWith('--type=')));
    evidence.browser.pid = browserMain?.[0] ?? null;
    evidence.browser.pidsBeforeClose = liveOwned(ownedRun, processes);
    if (!evidence.browser.pidsBeforeClose.length) throw new Error('browser process identity was not observed');
    evidence.browser.argv = browserMain?.[1].argv ?? null;
    const argv = evidence.browser.argv ?? [];
    const switchTokens = (name) => argv.filter((arg) => arg === `--${name}` || arg.startsWith(`--${name}=`));
    const featureToken = (name) => switchTokens(name).flatMap((token) => token.includes('=') ? token.slice(token.indexOf('=') + 1).split(',') : []);
    const enabled = featureToken('enable-features');
    const blinkEnabled = featureToken('enable-blink-features');
    const disabled = [...featureToken('disable-features'), ...featureToken('disable-blink-features')];
    const featureName = (value) => value.replace(/^\*/, '').split(/[<:]/, 1)[0].trim();
    const required = new Set([...WEBMCP_REQUIRED_FEATURES, ...WEBMCP_REQUIRED_BLINK_FEATURES]);
    const devToolsActivePort = existsSync(join(profile, 'DevToolsActivePort'));
    evidence.browser.effectiveFlags = argv.filter((arg) => arg.startsWith('--') && !arg.startsWith('--user-data-dir='));
    evidence.browser.guard = {
      hasRemoteDebuggingPipe: argv.includes('--remote-debugging-pipe'),
      remoteDebuggingPortTokens: switchTokens('remote-debugging-port'),
      hostResolverTokens: switchTokens('host-resolver-rules'),
      enableFeatureTokenCount: switchTokens('enable-features').length,
      enableBlinkFeatureTokenCount: switchTokens('enable-blink-features').length,
      enabledFeatures: enabled,
      blinkFeatures: blinkEnabled,
      disableConflicts: disabled.filter((value) => required.has(featureName(value))),
      noSandboxFlag: !switchTokens('no-sandbox').length,
      devToolsActivePortExists: devToolsActivePort,
      chromiumVersionMatches: evidence.browser.version === CHROMIUM_REQUIRED,
      accepted: argv.includes('--remote-debugging-pipe') && switchTokens('remote-debugging-port').length === 0 &&
        switchTokens('host-resolver-rules').length === 1 && switchTokens('host-resolver-rules')[0] === HOST_RESOLVER_DENY &&
        switchTokens('enable-features').length === 1 && WEBMCP_REQUIRED_FEATURES.every((feature) => enabled.includes(feature)) &&
        switchTokens('enable-blink-features').length === 1 && blinkEnabled.length === WEBMCP_REQUIRED_BLINK_FEATURES.length &&
        WEBMCP_REQUIRED_BLINK_FEATURES.every((feature) => blinkEnabled.includes(feature)) &&
        disabled.every((value) => !required.has(featureName(value))) && !devToolsActivePort &&
        evidence.browser.version === CHROMIUM_REQUIRED && !switchTokens('no-sandbox').length,
    };
    if (!evidence.browser.guard.accepted) throw new Error(`effective Chromium argv failed loopback/feature/pin checks: ${JSON.stringify(evidence.browser.guard)}`);

    page = context.pages()[0] ?? await context.newPage();
    await context.exposeBinding('__notifyObservation', (_source, record) => recordPageEvent(evidence, record));
    page.on('close', () => recordTimeline(evidence, 'page-close'));
    page.on('crash', () => recordTimeline(evidence, 'page-crash'));
    page.on('pageerror', (error) => noteError('pageerror', error));
    await guardLoopback(context, runtime.port, evidence.network.blocked);
    const cdp = await context.newCDPSession(page);
    recorder = makeRecorder(cdp, evidence);
    phase = 'page-enable';
    await recorder.send('Page.enable');
    phase = 'navigate-fixture';
    await page.goto(`${runtime.origin}/${testCase.id}?nonce=${encodeURIComponent(nonce)}`, { waitUntil: 'load', timeout: PAGE_OPERATION_TIMEOUT_MS });
    phase = 'webmcp-enable';
    await recorder.send('WebMCP.enable');
    phase = 'frame-tree';
    const tree = await recorder.send('Page.getFrameTree');
    const frameId = tree?.frameTree?.frame?.id;
    if (!frameId) throw new Error('Page.getFrameTree returned no main frame id');
    const tools = evidence.frames
      .filter((entry) => entry.dir === 'received' && entry.method === 'WebMCP.toolsAdded')
      .flatMap((entry) => entry.params?.tools ?? []);
    if (!tools.some((tool) => tool?.name === 'lifecycle')) {
      noteError('tool-registration', new Error('no lifecycle toolAdded frame observed'));
    } else {
      phase = 'invoke-tool';
      const invokeParams = { frameId, toolName: 'lifecycle', input: { q: testCase.handler === 'invalid' ? 'not-an-email' : nonce } };
      try {
        const result = await recorder.send('WebMCP.invokeTool', invokeParams);
        evidence.invocation.result = result;
        if (typeof result?.invocationId === 'string' && result.invocationId.length > 0) invocationId = result.invocationId;
        else {
          invokeError = 'invokeTool response did not contain a non-empty invocationId';
          evidence.invocation.error = invokeError;
        }
      } catch (error) {
        invokeError = String(error?.message ?? error);
        evidence.invocation.error = invokeError;
      }
    }

    phase = 'pre-action-observation';
    const preStartMono = performance.now();
    const preStartWall = Date.now();
    await sleep(PRE_ACTION_WINDOW_MS);
    const pre = await observePage(page, evidence, 'pre-action');
    const preSeq = pre.seq;
    const preFormActive = pre.value && typeof pre.value === 'object' ? pre.value.formActive ?? null : null;
    preAction = {
      start: preStartWall,
      end: Date.now(),
      startMonoMs: preStartMono,
      endMonoMs: pre.monoMs,
      windowMs: pre.monoMs - preStartMono,
      responseCount: responsesFor(evidence, invocationId, preSeq).length,
      responseCutoffSeq: preSeq,
      formActive: preFormActive,
    };

    const actionStartWall = Date.now();
    const actionStart = performance.now();
    let actionBoundary;
    if (testCase.action !== 'none' && (!invocationId || invokeError !== null)) {
      actionOutcome = 'skipped';
      actionError = 'action not dispatched because invocationId was absent or invokeTool failed';
      actionBoundary = recordTimeline(evidence, 'action-not-dispatched', { action: testCase.action, reason: 'missing-or-failed-invocation' });
    } else if (testCase.action === 'none') {
      actionOutcome = 'none';
      actionBoundary = recordTimeline(evidence, 'action-not-dispatched', { action: 'none', reason: 'scenario-has-no-explicit-action' });
    } else {
      actionOutcome = 'started';
      actionBoundary = recordTimeline(evidence, 'action-dispatch-start', { action: testCase.action, invocationId });
      evidence.actions.push({ seq: actionBoundary.seq, at: actionBoundary.at, monoMs: actionBoundary.monoMs, action: testCase.action, phase: 'dispatch-start' });
      try {
        const actionPromise = Promise.resolve().then(() => attemptAction(testCase.action, page));
        const actionResult = await Promise.race([
          actionPromise.then((value) => ({ settled: true, value }), (error) => ({ settled: true, error })),
          sleep(PAGE_OPERATION_TIMEOUT_MS).then(() => ({ settled: false, error: new Error('action observation window elapsed') })),
        ]);
        if (!actionResult.settled || actionResult.error) {
          actionOutcome = 'error';
          actionError = String(actionResult.error?.message ?? actionResult.error);
          noteError('action-dispatch', actionResult.error ?? new Error(actionError));
        } else {
          actionOutcome = 'completed';
          recordTimeline(evidence, 'action-dispatch-complete', { action: testCase.action });
          evidence.actions.push({ seq: evidence.sequence, at: new Date().toISOString(), monoMs: performance.now(), action: testCase.action, phase: 'dispatch-complete', result: actionResult.value ?? null });
        }
      } catch (error) {
        actionOutcome = 'error';
        actionError = String(error?.message ?? error);
        noteError('action-dispatch', error);
      }
    }

    if (testCase.handler === 'delayed' && actionOutcome !== 'skipped') {
      await sleep(DELAYED_RESPONSE_MS);
      await observePage(page, evidence, 'delayed-before-release');
      evidence.timing = { delayedResponseMs: DELAYED_RESPONSE_MS, releaseAttempted: true };
      const release = await releaseDelayedResponse(page, evidence);
      evidence.timing.releaseResult = release;
      if (release.error) noteError('delayed-response-release', new Error(release.error));
    }

    phase = 'after-observation';
    const elapsed = performance.now() - actionStart;
    await sleep(Math.max(0, AFTER_ACTION_WINDOW_MS - elapsed));
    const post = await observePage(page, evidence, 'after-action');
    const cutoffSeq = post.seq;
    const frameNavigations = evidence.frames
      .filter((entry) => entry.dir === 'received' && entry.method === 'Page.frameNavigated' && entry.seq > actionBoundary.seq && entry.seq <= cutoffSeq)
      .map((entry) => ({ seq: entry.seq, ...entry.params }));
    const submits = evidence.pageEvents
      .filter((entry) => entry.type === 'submit' && entry.seq <= cutoffSeq)
      .map((entry) => ({ seq: entry.seq, ...entry.value }));
    after = {
      start: actionStartWall,
      end: Date.now(),
      startMonoMs: actionStart,
      endMonoMs: post.monoMs,
      windowMs: post.monoMs - actionStart,
      observationLimitMs: AFTER_ACTION_WINDOW_MS,
      responseCutoffSeq: cutoffSeq,
      responses: responsesFor(evidence, invocationId, cutoffSeq),
      submits,
      navigations: frameNavigations,
      pageState: post.value,
    };
    if (actionOutcome === 'started') actionOutcome = 'not-completed-before-observation';
  } catch (error) {
    noteError(phase, error);
    if (phase === 'invoke-tool' && invokeError === null) {
      invokeError = String(error?.message ?? error);
      evidence.invocation.error = invokeError;
    }
  } finally {
    const close = await closeContextAndBrowser(context, ownedRun, evidence);
    evidence.browser.pidsAfterClose = close.remaining;
    evidence.teardown = {
      framesObservedThroughSeq: evidence.sequence,
      toolRespondedFrames: evidence.frames.filter((entry) => entry.method === 'WebMCP.toolResponded').map((entry) => ({ seq: entry.seq, params: entry.params })),
      toolsRemovedFrames: evidence.frames.filter((entry) => entry.method === 'WebMCP.toolsRemoved').map((entry) => ({ seq: entry.seq, params: entry.params })),
      frameCount: evidence.frames.length,
    };
    evidence.network.serverRequests = runtime.requestLog.filter((entry) => entry.nonce === nonce || entry.path === `/${testCase.id}`);
    const evidencePath = join(runtime.out, `${testCase.id}.json`);
    saveJson(evidencePath, evidence);
  }

  const noObservation = { windowMs: 0, responseCount: 0, responseCutoffSeq: null, formActive: null, observationError: 'no page observation was obtained' };
  const noAfterObservation = { windowMs: 0, observationLimitMs: AFTER_ACTION_WINDOW_MS, responseCutoffSeq: null, responses: [], submits: [], navigations: [], pageState: null, observationError: 'no after-action page observation was obtained' };
  const caseRecord = {
    id: testCase.id,
    nonce,
    autosubmit: testCase.autosubmit,
    action: testCase.action,
    invocationId,
    invokeError,
    preAction: preAction ?? noObservation,
    after: after ?? noAfterObservation,
    actionOutcome,
    actionError,
    observationComplete: Boolean(invocationId && preAction && after),
    evidence: {
      path: `corpus/evidence/round-21/runtime/${testCase.id}.json`,
      sha256: sha256(readFileSync(join(runtime.out, `${testCase.id}.json`))),
    },
  };
  runtime.receipt.cases.push(caseRecord);
  const statuses = caseRecord.after.responses.map((response) => String(response.status ?? 'status-not-reported'));
  runtime.log('stdout', `LIFECYCLE_OBSERVED ${testCase.id} pre=${caseRecord.preAction.responseCount} responses=${statuses.join(',') || 'none-in-window'} action=${actionOutcome}`);
  if (evidence.errors.length) runtime.log('stderr', `CASE_OBSERVATION_ERRORS ${testCase.id} ${evidence.errors.map((entry) => `${entry.phase}:${entry.message}`).join(' | ')}`);
  return caseRecord;
}

async function probePortClosed(port) {
  return new Promise((resolvePromise) => {
    const socket = createConnection({ host: '127.0.0.1', port });
    let finished = false;
    const done = (result) => {
      if (finished) return;
      finished = true;
      socket.destroy();
      resolvePromise(result);
    };
    socket.setTimeout(1000, () => done({ refused: false, reason: 'probe-timeout' }));
    socket.once('connect', () => done({ refused: false, reason: 'port-still-open' }));
    socket.once('error', (error) => done({ refused: error.code === 'ECONNREFUSED', reason: error.code ?? String(error) }));
  });
}

async function closeServer(server, port) {
  if (!server) return { closeCallback: { closed: true, notStarted: true }, portProbe: { refused: true, reason: 'server-not-started' } };
  server.closeAllConnections();
  const closeCallback = await Promise.race([
    new Promise((resolvePromise) => server.close((error) => resolvePromise({ closed: !error, error: error ? String(error.message ?? error) : null }))),
    sleep(SERVER_CLOSE_TIMEOUT_MS).then(() => ({ closed: false, error: 'server.close observation window elapsed' })),
  ]);
  const portProbe = await probePortClosed(port);
  return { closeCallback, portProbe };
}

async function runExperiment(out, producer) {
  const streams = { stdout: [], stderr: [] };
  const log = (stream, line) => {
    const text = `${line}\n`;
    streams[stream].push(text);
    (stream === 'stdout' ? process.stdout : process.stderr).write(text);
  };
  const receipt = {
    schema: 'tabi-round21-runtime-v1',
    startedAt: new Date().toISOString(),
    producer: { path: SELF_RELATIVE, sha256: producer.sha256 },
    environment: { node: process.version, chromium: null, playwright: null, flags: [] },
    timingWindows: {
      preActionSleepMs: PRE_ACTION_WINDOW_MS,
      afterActionObservationMs: AFTER_ACTION_WINDOW_MS,
      delayedRespondWithControlMs: DELAYED_RESPONSE_MS,
      pageOperationTimeoutMs: PAGE_OPERATION_TIMEOUT_MS,
      semantics: 'Finite observation windows only; not settle guarantees.',
    },
    cases: [],
    cleanup: { browserClosed: false, serverClosed: false },
    errors: [],
  };
  let playwright = null;
  let temp = null;
  let server = null;
  let port = null;
  let requestLog = [];
  const runtime = { out, receipt, log, routes: new Map(), requestLog, port: null, origin: null, temp: null, chromium: null, launchOptions: null };
  let infrastructureError = null;
  let serverProof = null;
  let tempRemoved = false;

  try {
    if (process.version !== NODE_REQUIRED) throw new Error(`node_version_mismatch: ${process.version}; required ${NODE_REQUIRED}`);
    playwright = resolvePlaywright();
    if (!playwright) throw new Error('playwright_unresolved');
    if (playwright.wrongVersion) throw new Error(`playwright_version_mismatch: ${playwright.version}; required ${PLAYWRIGHT_REQUIRED}`);
    receipt.environment.playwright = playwright.version;
    const launchOptions = featureLaunchOptions(EXTRA_FLAGS);
    receipt.environment.flags = launchOptions.args;
    receipt.environment.ignoreDefaultArgs = launchOptions.ignoreDefaultArgs;
    temp = mkdtempSync(join(tmpdir(), 'tabi-r21-lifecycle-'));
    const listening = await startFixtureServer(runtime.routes, requestLog);
    server = listening.server;
    port = listening.port;
    runtime.port = port;
    runtime.origin = `http://127.0.0.1:${port}`;
    runtime.temp = temp;
    runtime.chromium = playwright.chromium;
    runtime.launchOptions = launchOptions;
    runtime.requestLog = requestLog;
    receipt.server = { address: '127.0.0.1', port, scope: 'single ephemeral loopback HTTP server' };

    for (const testCase of EXPECTED_CASES) {
      const result = await runCase(testCase, runtime);
      if (!result.observationComplete) receipt.errors.push({ id: result.id, finding: 'case_observation_incomplete' });
    }
  } catch (error) {
    infrastructureError = error;
    receipt.errors.push({ phase: 'run', message: String(error?.message ?? error), stack: typeof error?.stack === 'string' ? error.stack : null });
    log('stderr', `RUN_ERROR ${String(error?.message ?? error)}`);
  } finally {
    serverProof = await closeServer(server, port);
    receipt.cleanup.serverClosed = serverProof.closeCallback.closed && serverProof.portProbe.refused;
    receipt.cleanup.server = serverProof;
    receipt.cleanup.browserClosed = receipt.cases.length === EXPECTED_CASES.length &&
      receipt.cases.every((entry) => entry.evidence && entry.observationComplete) &&
      EXPECTED_CASES.every((testCase) => {
        try { return JSON.parse(readFileSync(join(out, `${testCase.id}.json`), 'utf8')).browserPidsAfter.length === 0; }
        catch { return false; }
      });
    if (temp) {
      try { rmSync(temp, { recursive: true, force: true }); tempRemoved = !existsSync(temp); }
      catch (error) { receipt.errors.push({ phase: 'temporary-cleanup', message: String(error?.message ?? error) }); }
    }
    receipt.cleanup.tempRemoved = tempRemoved;
    receipt.finishedAt = new Date().toISOString();
    saveJson(join(out, 'receipt.json'), receipt);
    const complete = receipt.cases.length === EXPECTED_CASES.length && receipt.cases.every((entry) => entry.observationComplete);
    log('stdout', `LIFECYCLE_RUN_COMPLETE cases=${receipt.cases.length}/${EXPECTED_CASES.length} browserClosed=${receipt.cleanup.browserClosed} serverClosed=${receipt.cleanup.serverClosed}`);
    const exitCode = !infrastructureError && complete && receipt.cleanup.browserClosed && receipt.cleanup.serverClosed ? 0 : 1;
    saveJson(join(out, 'execution.json'), {
      schema: 'tabi-round21-execution-v1',
      producer: receipt.producer,
      startedAt: receipt.startedAt,
      finishedAt: receipt.finishedAt,
      argv: process.argv,
      exitCode,
      stdout: streams.stdout.join(''),
      stderr: streams.stderr.join(''),
    });
    return { receipt, exitCode };
  }
}

async function main() {
  let out;
  try {
    out = assertOutputPath(parseArgs(process.argv.slice(2)));
  } catch (error) {
    process.stderr.write(`${String(error?.message ?? error)}\n`);
    process.exitCode = 2;
    return;
  }
  mkdirSync(out, { recursive: true });
  const source = readFileSync(SELF);
  const producer = { path: SELF_RELATIVE, sha256: sha256(source) };
  const { exitCode } = await runExperiment(out, producer);
  process.exitCode = exitCode;
}

if (process.argv[1] && resolve(process.argv[1]) === SELF) {
  main().catch((error) => {
    process.stderr.write(`${error?.stack ?? error}\n`);
    process.exitCode = 1;
  });
}
